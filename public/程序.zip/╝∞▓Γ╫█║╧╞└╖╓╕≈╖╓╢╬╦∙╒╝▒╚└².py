import pandas as pd

# 读取含有综合评分的数据集
data = pd.read_excel(r"D:\\BaiduNetdiskDownload\\C题-全部数据\\C题-全部数据\\附件3\\result.xlsx")

# 提取综合评分列
scores = data['综合评分']

# 定义每个分数段的排名范围及其比例
score_ranges = {
    10: 0.5,
    9: 1.0,
    8: 1.5,
    7: 4.0,
    6: 7.0,
    5: 9.0,
    4: 12.0,
    3: 65.0
}

# 计算每个分数段的排名范围
total_percentage = sum(score_ranges.values())
normalized_score_ranges = {score: percentage / total_percentage for score, percentage in score_ranges.items()}

# 统计每个分数段内的数据数量
score_counts = {score: ((scores <= score) & (scores > next_score)).sum() for score, next_score in zip(score_ranges.keys(), list(score_ranges.keys())[1:])}
# 处理最后一个分数段
score_counts[list(score_ranges.keys())[-1]] = (scores <= list(score_ranges.keys())[-1]).sum()

# 计算每个分数段的比例
total_count = len(scores)
score_percentages = {score: count / total_count for score, count in score_counts.items()}

# 输出结果
print("实际分数段比例：")
print(score_percentages)
print("\n期望分数段比例：")
print(normalized_score_ranges)

