library(tm)
library(openxlsx)
library(pdftools)
library(dplyr)
library(quanteda)   # 添加 quanteda 库
library(textTinyR)
library(topicmodels)
# 加载所需的库
library(textmineR)
library(httr)
# 加载所需的库
library(reticulate)  # nolint
library(stringr)     # 处理字符串
library(spacyr)


# 设定数据目录
data_dir <- "D:/BaiduNetdiskDownload/C题-全部数据/C题-全部数据"

# 读取赛题和评阅要点 PDF 文件
competition_topic <- pdftools::pdf_text(file.path(data_dir, "附件2", "question.pdf"))
evaluation_criteria <- pdftools::pdf_text(file.path(data_dir, "附件2", "rate.pdf"))

# 准备论文
papers_dir <- file.path(data_dir, "附件1")

# 获取 papers_dir 目录下的所有 PDF 文件路径
pdf_files <- list.files(papers_dir, pattern = "\\.pdf$", full.names = TRUE)

# 遍历每个 PDF 文件并提取文本内容
papers_text_list <- lapply(pdf_files, pdftools::pdf_text)

# 将提取的文本内容与论文编号相关联
# 假设文件名的格式为 "paperID.pdf"，并且 paperID 代表论文编号
papers_df <- data.frame(
  论文编号 = gsub("^(.*/)?(.*?)\\.pdf$", "\\2", pdf_files),
  文本内容 = sapply(papers_text_list, paste, collapse = "\n"),
  stringsAsFactors = FALSE
)

# 合并赛题描述的所有页面文本为一个单一字符串
full_competition_topic <- paste(competition_topic, collapse = "\n")

# 合并评阅要点的所有页面文本为一个单一字符串
full_evaluation_criteria <- paste(evaluation_criteria, collapse = "\n")

# 创建结果数据框
result_df <- data.frame(
  论文编号 = character(),
  完整性 = numeric(),

  摘要质量评分 = numeric(),
  写作水平 = numeric(),

  stringsAsFactors = FALSE
)

# 判断论文中是否包含指定部分
has_section <- function(paper_text, section_name) {
  if (grepl(section_name, paper_text, ignore.case = TRUE)) {
    return(1)
  } else {
    return(0)
  }
}




# 定义完整性评价函数
evaluate_completeness <- function(paper_text) {
  # 定义要评价的部分
  sections <- c("摘要","关键词","目录","意义","原理","数据预处理", "建立模型", "描述",
                "分析","总结","参考文献","流程","热点问题","答复意见","留言分类")

  # 逐个判断各个部分的完整性，并计算平均分作为综合评分
  completeness_scores <- sapply(sections, function(section) has_section(paper_text, section) * 10)
  overall_score <- mean(completeness_scores)

  return(c(completeness_scores, overall_score))
}




extract_summary_and_content <- function(paper_text) {
  # 使用正则表达式找到摘要和正文的开始和结束位置
  abstract_start <- regexpr('摘要', paper_text)
  abstract_end <- regexpr('目录', paper_text)
  body_start <- abstract_end
  body_end <- nchar(paper_text)

  # 提取摘要和正文
  summary <- ifelse(abstract_start != -1 && abstract_end != -1, substr(paper_text, abstract_start, abstract_end), NA)
  content <- ifelse(body_start != -1 && body_end != -1, substr(paper_text, body_start, body_end), NA)

  list(summary = summary, content = content)
}


calculate_coverage <- function(summary, content) {
  # 确保摘要和正文不为空
  if (is.na(summary) || is.na(content) || summary == "" || content == "") {
    return(NA)
  }
  # 创建词袋模型

  summary_tokens <- quanteda::tokens(summary)
  content_tokens <- quanteda::tokens(content)
  summary_bag_of_words <- quanteda::dfm(summary_tokens)
  content_bag_of_words <- quanteda::dfm(content_tokens)
  # 提取摘要和正文中的单词及其出现的次数
  summary_word_counts <- colSums(summary_bag_of_words)
  content_word_counts <- colSums(content_bag_of_words)
  # 设置一个阈值，如果正文中的出现次数低于这个阈值，则这个词汇不计入覆盖程度的计算
  threshold <- mean(content_word_counts)
  # 计算符合要求的摘要词汇的数量
  valid_summary_words <- sum((summary_word_counts %in% content_word_counts) & (content_word_counts >= threshold)) # 计算覆盖程度
  coverage <- valid_summary_words / length(summary_word_counts)
  # 返回0表示没有覆盖，避免NA
  if (is.na(coverage)) {
    return(0)
  } else {
    return(coverage)
  }
}


evaluate_summary <- function(summary, content) {
  coverage <- calculate_coverage(summary, content)
  # 如果覆盖程度是NA
  if (is.na(coverage)) {
    summary_quality_score <- 7.8
  } else {
    # 根据覆盖程度设置梯度评分
    if (coverage >= 0.98) {
      summary_quality_score <- 10
    } else if (coverage >= 0.72) {
      summary_quality_score <- 8
    } else if (coverage >= 0.65) {
      summary_quality_score <- 7.5
    } else if (coverage >= 0.6) {
      summary_quality_score <- 6.5
    } else {
      summary_quality_score <- 6
    }
  }
  return(summary_quality_score)
}


# 定义写作水平评价函数
evaluate_writing_quality <- function(paper_text) {
  # 检查文本内容是否为空
  if (is.na(paper_text) || paper_text == "") {
    return(0)  # 如果文本内容为空，则返回0分
  }


  # 论证逻辑评价（关键词共现分析）
  keywords <- c("问题","数据预处理","特征提取", "原理", "模型", "效果")  # 关键词列表
  co_occur_keywords <- sum(sapply(keywords, function(word) {
    any(str_detect(tolower(paper_text), word))  # 检查每个关键词是否至少出现一次
  }))
  logic_score <- ifelse(co_occur_keywords == 6, 10, max(0, 10 - (6 - co_occur_keywords) * 2))  # 论证逻辑得分（10分满分，每缺失一个关键词扣2分，最低得分为0）


  # 过渡词检测评价
  transition_words <- c("然而", "因此", "另外", "而且", "例如","所以","相应地","这表明","综上","得到","最后","即")  # 过渡词列表
  transition_count <- sum(sapply(transition_words, function(word) {
    ifelse(str_count(paper_text, word) > 0, 1, 0)  # 如果词出现次数大于0，则记为1，否则记为0
  }))  # 计算过渡词出现次数
  transition_score <- min(10, max(0, 10*transition_count/ length(transition_words)))  # 过渡词得分（范围在0到10之间）


  # 初始化图表格式得分为0
  chart_format_score <- 0

  # 检查图表的标题是否出现在图表的上方或下方
  if (grepl("图[0-9]+[:：].*\n.*\1", paper_text) && grepl("表[0-9]+[:：].*\n.*\1", paper_text)) {
    chart_format_score <- 10  # 如果满足规范格式，则为满分
  }
  else {
    chart_format_score <- 8  # 如果不满足规范格式，则为8分
  }

  # 综合评分（示例：各项评分加权平均）
  overall_score <- (logic_score*0.5 + transition_score*0.2 + chart_format_score*0.3)  # 加权平均
  return(overall_score)
}



# 对每篇论文进行写作水平评价
for (i in 1:nrow(papers_df)) { # nolint
  # 获取论文编号和文本内容
  paper_id <- papers_df[i, "论文编号"]
  paper_text <- papers_df[i, "文本内容"]

  # 评价论文写作水平
  writing_quality_score <- evaluate_writing_quality(paper_text)

  # 评价论文完整性
  completeness_scores <- evaluate_completeness(paper_text)
  # 将综合评分赋值给completeness_scores向量的最后一个元素
  completeness_score<- completeness_scores[length(completeness_scores)]

  # 提取摘要和正文
  summary_and_content <- extract_summary_and_content(paper_text)
  summary <- summary_and_content$summary
  content <- summary_and_content$content
  # 评价摘要质量
  summary_quality_score <- evaluate_summary(summary, content)

  # 更新结果数据框
  result_df[i, ] <- c(paper_id, completeness_score, summary_quality_score,writing_quality_score)
}


setwd("D:/")

# 保存结果到 result.xlsx 文件中
output_file <- file.path(data_dir, "附件3", "result.xlsx")
write.xlsx(result_df, output_file, rowNames = FALSE)

