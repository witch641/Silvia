
library(topicmodels)
library(tm)
library(slam)

# 设定数据目录
data_dir <- "D:/BaiduNetdiskDownload/C题-全部数据/C题-全部数据"

# 读取赛题和评阅要点 PDF 文件
competition_topic <- pdftools::pdf_text(file.path(data_dir, "附件2", "question.pdf"))
evaluation_criteria <- pdftools::pdf_text(file.path(data_dir, "附件2", "rate.pdf"))

# 准备论文
papers_dir <- file.path(data_dir, "附件1")

# 获取 papers_dir 目录下的所有 PDF 文件路径
pdf_files <- list.files(papers_dir, pattern = "\\.pdf$", full.names = TRUE)

# 遍历每个 PDF 文件并提取文本内容
papers_text_list <- lapply(pdf_files, pdftools::pdf_text)

# 将提取的文本内容与论文编号相关联
# 假设文件名的格式为 "paperID.pdf"，并且 paperID 代表论文编号
papers_df <- data.frame(
  论文编号 = gsub("^(.*/)?(.*?)\\.pdf$", "\\2", pdf_files),
  文本内容 = sapply(papers_text_list, paste, collapse = "\n"),
  stringsAsFactors = FALSE
)


# 创建结果数据框
result_df <- data.frame(
  论文编号 = character(),

  实质性 = numeric(),

  stringsAsFactors = FALSE
)



extract_summary_and_content <- function(paper_text) {
  # 使用正则表达式找到摘要和正文的开始和结束位置
  abstract_start <- regexpr('摘要', paper_text)
  abstract_end <- regexpr('目录', paper_text)
  body_start <- abstract_end
  body_end <- nchar(paper_text)

  # 提取摘要和正文
  summary <- ifelse(abstract_start != -1 && abstract_end != -1, substr(paper_text, abstract_start, abstract_end), NA)
  content <- ifelse(body_start != -1 && body_end != -1, substr(paper_text, body_start, body_end), NA)

  list(summary = summary, content = content)
}




#
remove_custom_stopwords <- function(content, stopwords) {
  for (stopword in stopwords) {
    # 使用固定模式匹配，避免正则表达式的特殊字符干扰
    content <- gsub(paste0("\\b", stopword, "\\b"), "", content, fixed = TRUE)
  }
  return(content)
}

# 遍历每个 PDF 文件并提取正文内容
papers_text_list <- lapply(pdf_files, function(file) {
  paper_text <- pdftools::pdf_text(file)
  paper_content <- extract_summary_and_content(paper_text)$content
  return(paper_content)
})

# 在预处理之前，先提取正文部分
papers_df$正文内容 <- sapply(papers_df$文本内容, function(text) {
  extract_summary_and_content(text)$content
})


# 定义预处理函数，使用自定义的停用词移除函数
preprocess_content <- function(content) {

  content <- tolower(content)
  content <- removePunctuation(content)
  content <- removeNumbers(content)


  return(content)
}


# 对正文内容进行预处理
papers_df$正文内容 <- sapply(papers_df$正文内容, preprocess_content)

# 修改 evaluate_substance 函数，添加异常处理逻辑
evaluate_substance <- function(content) {
  # 检查文本内容是否为空或零长度
  if (is.null(content) || nchar(content) == 0) {
    # 如果文本内容为空或零长度，返回一个默认得分（比如4分）
    return(4)
  }

  # 创建语料库
  paper_corpus <- Corpus(VectorSource(content))
  # 对语料库进行预处理
  paper_corpus <- tm_map(paper_corpus, content_transformer(tolower))
  paper_corpus <- tm_map(paper_corpus, removePunctuation)
  paper_corpus <- tm_map(paper_corpus, removeNumbers)

  # 创建文档词项矩阵
  dtm <- DocumentTermMatrix(paper_corpus)
  dtm <- removeSparseTerms(dtm, 0.95)

  # 尝试训练 LDA 主题模型，如果出现异常（比如每行都是零向量），则返回默认得分
  tryCatch({
    lda_model <- LDA(dtm, k = 20, control = list(alpha = 50/5, seed = 1234))
    # 获取主题关键词
    topic_keywords <- terms(lda_model, 20)
    # 判断主题关键词是否和赛题相关
    topic_score <- sum(topic_keywords %in% c("挖掘", "分类", "答复意见","主题","特征提取","聚类","算法","词频","分词","留言","模型","指标","热点问题","问政","平台","聚类","评价"))
    topic_score_scaled <- (topic_score / length(c("挖掘", "分类", "答复意见","主题","特征提取","聚类","算法","词频","分词","留言","模型","指标","热点问题","问政","平台","聚类","评价"))*6)


    if (topic_score_scaled == 0) {
      topic_score_scaled <- 5.5
    }

    return(topic_score_scaled)
  }, error = function(e) {
    # 如果出现异常，返回默认得分（比如4分）
    return(4)
  })
}

# 定义获取丰富程度的函数
get_richness <- function(content) {
  # 计算论文的字数
  num_words <- nchar(content)

  # 计算字数得分
  if (num_words >= 30000) {
    richness_score <- 10
  } else {
    # 根据每比2万字少0.2万减2分的规则计算得分
    additional_score <- floor((30000 - num_words) / 24000 * 10 / 2) * 2
    richness_score <- max(2, 10 - additional_score)
  }

  return(richness_score)
}

# 示例：对每篇论文进行实质性评价和丰富程度评价，并计算综合得分
for (i in 1:nrow(papers_df)) {
  # 获取论文编号和文本内容
  paper_id <- papers_df[i, "论文编号"]
  content <- papers_df[i, "文本内容"]
  # 检查文本内容是否为空
  # 检查文本内容是否为空或零长度
  if (is.null(content) || nchar(content) == 0) {
    # 如果文本内容为空或零长度，跳过该篇论文的处理
    result_df[i, "论文编号"] <- paper_id
    result_df[i, "实质性"] <- 4
    next
  }

  # 评价论文实质性
  substance_score <- evaluate_substance(content)

  # 计算丰富程度得分
  richness_score <- get_richness(content)

  # 计算综合得分
  combined_score <- (substance_score * 0.35) + (richness_score * 0.65)

  # 更新结果数据框
  result_df[i, "论文编号"] <- paper_id
  result_df[i, "实质性"] <- combined_score

}


setwd("D:/")


output_file <- file.path(data_dir, "附件3", "substance.xlsx")
write.xlsx(result_df, output_file, rowNames = FALSE)

