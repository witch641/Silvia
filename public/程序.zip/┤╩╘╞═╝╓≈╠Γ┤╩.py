import jieba
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np

# 读取文本文件
file_path = r"D:\BaiduNetdiskDownload\C题-全部数据\C题-全部数据\附件2\questionrate.txt"
with open(file_path, "r", encoding='utf-8') as f:
    text = f.read()

# 中文分词
words = jieba.lcut(text)

# 词频统计，并排除包含“问题”的高频词
exclude_words = {'问题','08','00','10','18','给出','相关','工作','需要','44','14','一个','论文','泰迪杯','作品'}
word_counts = {}
for word in words:
    if word not in exclude_words and len(word) > 1:
        word_counts[word] = word_counts.get(word, 0) + 1

# 生成词云
cloud_mask = np.array(Image.open(r"D:\chaos\chaos in chaos\png\cat.png"))
wordcloud = WordCloud(background_color='white',
                      mask=cloud_mask,
                      font_path=r'C:\Windows\Fonts\msyh.ttc',
                      max_words=100,
                      max_font_size=80)
wordcloud.generate_from_frequencies(word_counts)

# 显示词云图
plt.figure(figsize=(10, 8))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.show()
