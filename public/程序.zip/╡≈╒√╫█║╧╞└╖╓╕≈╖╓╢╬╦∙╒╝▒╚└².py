
import pandas as pd

# 读取含有综合评分的数据集
data = pd.read_excel(r"C:\\Users\\一小丝\\Desktop\\期末作业\\建模\\result.xlsx")

# 提取论文编号、完整性、实质性、摘要质量评分、写作水平和综合评分列
paper_id = data['论文编号']
integrity = data['完整性']
substance = data['实质性']
abstract_quality = data['摘要']
writing_level = data['写作水平']
scores = data['综合评分']

# 计算每个分数段的排名范围
score_ranges = {
    10: 0.5,
    9: 1.0,
    8: 1.5,
    7: 4.0,
    6: 7.0,
    5: 9.0,
    4: 12.0,
    3: 65.0
}

# 计算每个分数段的排名范围
total_percentage = 0
for score, percentage in score_ranges.items():
    total_percentage += percentage
    score_ranges[score] = total_percentage

# 遍历综合评分，调整综合评分
adjusted_scores = []
for score in scores:
    # 计算排名百分比
    rank_percent = (scores > score).mean() * 100

    # 根据排名百分比确定所在分数段
    adjusted_score = None
    for s, percentage in score_ranges.items():
        if rank_percent <= percentage:
            adjusted_score = s
            break

    adjusted_scores.append(adjusted_score)

# 更新数据集中的综合评分列
data['综合评分'] = adjusted_scores

# 保存调整后的数据集
data.to_excel(r"C:\\Users\\一小丝\\Desktop\\期末作业\\建模\\result2.xlsx", index=False)
