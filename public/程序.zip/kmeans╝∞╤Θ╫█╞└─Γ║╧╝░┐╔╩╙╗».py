import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# 读取Excel文件
file_path = "C:\\Users\\一小丝\\Desktop\\期末作业\\建模\\1.xlsx"
data = pd.read_excel(file_path)
data=data.dropna()

# 选择要用于聚类的特征
X = data[['实质性', '写作水平']]

# 标准化数据
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 使用PCA进行降维
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# 使用K均值聚类
kmeans = KMeans(n_clusters=3, random_state=42)
data['cluster'] = kmeans.fit_predict(X_pca)

# 绘制聚类结果
plt.figure(figsize=(10, 6))
plt.scatter(X_pca[data['cluster'] == 0][:, 0], X_pca[data['cluster'] == 0][:, 1], s=50, c='lightgreen', label='poor')

plt.scatter(X_pca[data['cluster'] == 2][:, 0], X_pca[data['cluster'] == 2][:, 1], s=50, c='lightblue', label='average')
plt.scatter(X_pca[data['cluster'] == 1][:, 0], X_pca[data['cluster'] == 1][:, 1], s=50, c='orange', label='excellent')
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=200, c='red', marker='*', label='Centroids')

# 在每个数据点上显示publisher的名字
for i, txt in enumerate(np.round_(data['综合评分'], decimals=1)): # 保留一位小数
    plt.annotate(txt, (X_pca[i, 0], X_pca[i, 1]))

plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.title('K-Means Clustering')
plt.legend()
plt.show()
